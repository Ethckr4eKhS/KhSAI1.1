package uz.jarvis.assistant;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MainActivity extends Activity {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private WebView web;
    private SpeechRecognizer sr;
    private boolean listening = false;
    private long lastRms = 0;
    private String site;
    private Phone phone;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        site = getString(R.string.site);
        phone = new Phone(this);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#050B12"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setTextZoom(100);
        s.setSupportZoom(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Bridge(), "JarvisNative");

        final String host = Uri.parse(site).getHost();
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if (host != null && host.equalsIgnoreCase(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    // ignore
                }
                return true;
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) {
                    v.loadDataWithBaseURL(null, offlineHtml(), "text/html", "utf-8", null);
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton("Ha", (d, w) -> r.confirm())
                        .setNegativeButton("Yo'q", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }
        });

        SharedPreferences sp = getSharedPreferences("j", MODE_PRIVATE);
        if (!sp.getBoolean("asked", false)) {
            sp.edit().putBoolean("asked", true).apply();
            requestPermissions(new String[]{
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.READ_CONTACTS,
                    Manifest.permission.CALL_PHONE}, 1);
        }

        web.loadUrl(site);
    }

    private String offlineHtml() {
        return "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style=\"margin:0;height:100vh;display:flex;flex-direction:column;align-items:center;"
                + "justify-content:center;gap:18px;background:#050b12;color:#eaf6f7;font:16px sans-serif\">"
                + "<div>Internet aloqasi yo'q</div>"
                + "<button style=\"padding:12px 26px;border:0;border-radius:14px;background:#35e0c6;"
                + "color:#04121a;font-size:16px\" onclick=\"location.href='" + site + "'\">Qayta urinish</button>"
                + "</body></html>";
    }

    // ---- JS -> Java ----

    public class Bridge {
        @JavascriptInterface
        public void listen(final String lang) {
            ui.post(() -> startListen(lang == null || lang.isEmpty() ? "uz-UZ" : lang));
        }

        @JavascriptInterface
        public void stopListen() {
            ui.post(() -> {
                if (sr != null) sr.stopListening();
            });
        }

        @JavascriptInterface
        public void cancelListen() {
            ui.post(() -> killSr(true));
        }

        @JavascriptInterface
        public void keepAwake(final boolean on) {
            ui.post(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public String act(final String name, final String args) {
            final String[] out = new String[1];
            final CountDownLatch latch = new CountDownLatch(1);
            ui.post(() -> {
                try {
                    out[0] = phone.run(name, args);
                } catch (Throwable t) {
                    out[0] = Phone.err("xato");
                }
                latch.countDown();
            });
            try {
                latch.await(5, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                // ignore
            }
            return out[0] != null ? out[0] : Phone.err("vaqt tugadi");
        }
    }

    // ---- Java -> JS ----

    private void ev(String k, String v) {
        final String code = "window.__srEv&&window.__srEv(" + JSONObject.quote(k) + ","
                + JSONObject.quote(v == null ? "" : v) + ")";
        ui.post(() -> {
            if (web != null) web.evaluateJavascript(code, null);
        });
    }

    // ---- speech recognition ----

    private static String first(Bundle r) {
        ArrayList<String> l = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        return (l != null && !l.isEmpty()) ? l.get(0) : null;
    }

    private void startListen(String lang) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 2);
            ev("err", "not-allowed");
            ev("end", "");
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            ev("err", "service-not-allowed");
            ev("end", "");
            return;
        }
        killSr(false);
        final SpeechRecognizer me = SpeechRecognizer.createSpeechRecognizer(this);
        sr = me;
        listening = true;
        me.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {
                if (sr == me) ev("start", "");
            }

            @Override
            public void onBeginningOfSpeech() {
            }

            @Override
            public void onRmsChanged(float rmsdB) {
                long n = System.currentTimeMillis();
                if (sr == me && n - lastRms > 70) {
                    lastRms = n;
                    ev("rms", String.valueOf(rmsdB));
                }
            }

            @Override
            public void onBufferReceived(byte[] buffer) {
            }

            @Override
            public void onEndOfSpeech() {
            }

            @Override
            public void onError(int c) {
                if (sr != me) return;
                String code;
                if (c == 6 || c == 7) code = "no-speech";
                else if (c == 1 || c == 2 || c == 4 || c == 11) code = "network";
                else if (c == 3) code = "audio-capture";
                else if (c == 8 || c == 10) code = "busy";
                else if (c == 9) code = "not-allowed";
                else if (c == 12 || c == 13) code = "language-not-supported";
                else code = "aborted";
                listening = false;
                ev("err", code);
                ev("end", "");
                release(me);
            }

            @Override
            public void onResults(Bundle results) {
                if (sr != me) return;
                String t = first(results);
                listening = false;
                if (t != null) ev("res", t);
                ev("end", "");
                release(me);
            }

            @Override
            public void onPartialResults(Bundle partial) {
                if (sr != me) return;
                String t = first(partial);
                if (t != null) ev("res", t);
            }

            @Override
            public void onEvent(int eventType, Bundle params) {
            }
        });

        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        me.startListening(i);
    }

    private void release(final SpeechRecognizer me) {
        ui.post(() -> {
            try {
                me.destroy();
            } catch (Exception e) {
                // ignore
            }
            if (sr == me) sr = null;
        });
    }

    private void killSr(boolean notify) {
        SpeechRecognizer me = sr;
        boolean was = listening;
        sr = null;
        listening = false;
        if (me != null) {
            try {
                me.cancel();
                me.destroy();
            } catch (Exception e) {
                // ignore
            }
        }
        if (notify && was) {
            ev("err", "aborted");
            ev("end", "");
        }
    }

    // ---- lifecycle ----

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        ui.post(() -> {
            if (web != null) web.evaluateJavascript("window.__perm&&window.__perm()", null);
        });
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("(window.__back&&window.__back())?'1':'0'", v -> {
            if (!"\"1\"".equals(v)) moveTaskToBack(true);
        });
    }

    @Override
    protected void onPause() {
        killSr(true);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        killSr(false);
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
