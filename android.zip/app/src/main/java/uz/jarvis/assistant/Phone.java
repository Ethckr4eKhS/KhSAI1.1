package uz.jarvis.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.database.Cursor;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.AlarmClock;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.view.KeyEvent;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Official Android actions only (no accessibility tricks). Always called on the UI thread. */
class Phone {
    private static final Map<String, String> ALIAS = new HashMap<>();

    static {
        ALIAS.put("yutub", "youtube");
        ALIAS.put("kamera", "camera");
        ALIAS.put("sozlamalar", "settings");
        ALIAS.put("sozlama", "settings");
        ALIAS.put("galereya", "gallery");
        ALIAS.put("soat", "clock");
        ALIAS.put("kalkulyator", "calculator");
        ALIAS.put("kontaktlar", "contacts");
        ALIAS.put("xaritalar", "maps");
        ALIAS.put("xarita", "maps");
        ALIAS.put("brauzer", "chrome");
    }

    private final Activity a;

    Phone(Activity a) {
        this.a = a;
    }

    static String js(Object... kv) {
        JSONObject o = new JSONObject();
        try {
            for (int i = 0; i + 1 < kv.length; i += 2) o.put((String) kv[i], kv[i + 1]);
        } catch (Exception e) {
            // ignore
        }
        return o.toString();
    }

    static String err(String m) {
        return js("error", m);
    }

    String run(String name, String json) {
        try {
            JSONObject j = new JSONObject(json == null || json.isEmpty() ? "{}" : json);
            switch (name) {
                case "alarm": return alarm(j);
                case "timer": return timer(j);
                case "volume": return volume(j);
                case "torch": return torch(j);
                case "media": return media(j);
                case "url": return url(j);
                case "find_app": return findApp(j);
                case "launch": return launch(j);
                case "find_contact": return findContact(j);
                case "call": return call(j);
                case "perms": return perms();
                case "ask_perms": return askPerms();
                case "app_settings": return appSettings();
                default: return err("noma'lum amal");
            }
        } catch (Exception e) {
            return err("xato: " + e.getMessage());
        }
    }

    private boolean has(String p) {
        return a.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private String start(Intent i, String okJson) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.startActivity(i);
            return okJson;
        } catch (Exception e) {
            return err("mos ilova topilmadi");
        }
    }

    // ---- alarm / timer ----

    private String alarm(JSONObject j) {
        int h = j.optInt("hour", -1);
        int m = j.optInt("minute", 0);
        if (h < 0 || h > 23 || m < 0 || m > 59) return err("vaqt noto'g'ri");
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
        i.putExtra(AlarmClock.EXTRA_HOUR, h);
        i.putExtra(AlarmClock.EXTRA_MINUTES, m);
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        String label = j.optString("label", "");
        if (!label.isEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label);
        if (j.optBoolean("daily", false)) {
            ArrayList<Integer> days = new ArrayList<>();
            for (int d = Calendar.SUNDAY; d <= Calendar.SATURDAY; d++) days.add(d);
            i.putExtra(AlarmClock.EXTRA_DAYS, days);
        }
        return start(i, js("ok", true, "time", String.format(Locale.US, "%02d:%02d", h, m)));
    }

    private String timer(JSONObject j) {
        int s = j.optInt("seconds", 0);
        if (s < 1 || s > 86400) return err("sekund noto'g'ri");
        Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
        i.putExtra(AlarmClock.EXTRA_LENGTH, s);
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        String label = j.optString("label", "");
        if (!label.isEmpty()) i.putExtra(AlarmClock.EXTRA_MESSAGE, label);
        return start(i, js("ok", true, "seconds", s));
    }

    // ---- volume / torch / media ----

    private String volume(JSONObject j) {
        AudioManager am = (AudioManager) a.getSystemService(Context.AUDIO_SERVICE);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int cur = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        int step = Math.max(1, max / 5);
        String dir = j.optString("direction", "");
        int target;
        if (dir.equals("up")) {
            target = cur + step;
        } else if (dir.equals("down")) {
            target = cur - step;
        } else if (j.has("percent")) {
            target = Math.round(max * j.optInt("percent", 50) / 100f);
        } else {
            return err("percent yoki direction kerak");
        }
        target = Math.max(0, Math.min(max, target));
        am.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI);
        return js("ok", true, "percent", Math.round(target * 100f / max));
    }

    private String torch(JSONObject j) {
        boolean on = j.optBoolean("on", true);
        try {
            CameraManager cm = (CameraManager) a.getSystemService(Context.CAMERA_SERVICE);
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics c = cm.getCameraCharacteristics(id);
                Boolean flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer face = c.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(flash) && face != null
                        && face.intValue() == CameraCharacteristics.LENS_FACING_BACK) {
                    cm.setTorchMode(id, on);
                    return js("ok", true, "on", on);
                }
            }
            return err("fonar topilmadi");
        } catch (Exception e) {
            return err("fonarni boshqarib bo'lmadi");
        }
    }

    private String media(JSONObject j) {
        String s = j.optString("action", "");
        int k;
        switch (s) {
            case "play":
            case "pause":
            case "play_pause": k = KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE; break;
            case "next": k = KeyEvent.KEYCODE_MEDIA_NEXT; break;
            case "previous": k = KeyEvent.KEYCODE_MEDIA_PREVIOUS; break;
            case "stop": k = KeyEvent.KEYCODE_MEDIA_STOP; break;
            default: return err("noma'lum amal");
        }
        AudioManager am = (AudioManager) a.getSystemService(Context.AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, k));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, k));
        return js("ok", true);
    }

    // ---- links / apps ----

    private String url(JSONObject j) {
        String u = j.optString("url", "");
        if (!u.startsWith("http://") && !u.startsWith("https://")) return err("faqat http yoki https");
        return start(new Intent(Intent.ACTION_VIEW, Uri.parse(u)), js("ok", true));
    }

    private static String norm(String s) {
        return s == null ? "" : s.toLowerCase(Locale.ROOT).replaceAll("[^\\p{L}\\p{N}]", "");
    }

    private String findApp(JSONObject j) {
        String q = norm(j.optString("name", ""));
        if (q.isEmpty()) return err("ilova nomi kerak");
        String al = ALIAS.get(q);
        if (al != null) q = al;
        PackageManager pm = a.getPackageManager();
        Intent mi = new Intent(Intent.ACTION_MAIN);
        mi.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(mi, 0);
        String bestPkg = null;
        String bestLabel = null;
        int best = 0;
        for (ResolveInfo r : list) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(a.getPackageName())) continue;
            String label = String.valueOf(r.loadLabel(pm));
            String n = norm(label);
            if (n.isEmpty()) continue;
            int sc = 0;
            if (n.equals(q)) sc = 4;
            else if (n.startsWith(q)) sc = 3;
            else if (n.contains(q)) sc = 2;
            else if (n.length() >= 4 && q.contains(n)) sc = 1;
            if (sc > best) {
                best = sc;
                bestPkg = pkg;
                bestLabel = label;
            }
        }
        if (bestPkg == null) return err("bunday ilova topilmadi");
        return js("ok", true, "label", bestLabel, "pkg", bestPkg);
    }

    private String launch(JSONObject j) {
        String p = j.optString("pkg", "");
        Intent i = a.getPackageManager().getLaunchIntentForPackage(p);
        if (i == null) return err("ilova ochilmadi");
        return start(i, js("ok", true));
    }

    // ---- contacts / calls ----

    private Map<String, String> queryContacts(String q) {
        Map<String, String> m = new LinkedHashMap<>();
        Cursor c = null;
        try {
            c = a.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    new String[]{
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER},
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                    new String[]{"%" + q + "%"},
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC");
            if (c != null) {
                while (c.moveToNext()) {
                    String n = c.getString(0);
                    String p = c.getString(1);
                    if (n != null && p != null && !m.containsKey(n)) m.put(n, p);
                }
            }
        } catch (Exception e) {
            // ignore
        } finally {
            if (c != null) c.close();
        }
        return m;
    }

    private String findContact(JSONObject j) {
        String name = j.optString("name", "").trim();
        if (name.isEmpty()) return err("kontakt ismi kerak");
        if (!has(Manifest.permission.READ_CONTACTS)) {
            a.requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, 3);
            return err("kontaktlarga ruxsat kerak. Ruxsat berib, buyruqni qaytaring");
        }
        Map<String, String> found = queryContacts(name);
        if (found.isEmpty()) {
            for (String t : name.split("\\s+")) {
                if (t.length() >= 3) {
                    found = queryContacts(t);
                    if (!found.isEmpty()) break;
                }
            }
        }
        if (found.isEmpty()) return err("kontakt topilmadi");
        if (found.size() > 1) {
            JSONArray arr = new JSONArray();
            for (String n : found.keySet()) {
                if (arr.length() >= 5) break;
                arr.put(n);
            }
            return js("error", "bir nechta kontakt mos keldi, qaysi biri ekanini so'ra", "matches", arr);
        }
        Map.Entry<String, String> e = found.entrySet().iterator().next();
        return js("ok", true, "name", e.getKey(), "number", e.getValue());
    }

    private String call(JSONObject j) {
        String n = j.optString("number", "").replaceAll("[^0-9+*#]", "");
        if (n.isEmpty()) return err("raqam kerak");
        Uri u = Uri.fromParts("tel", n, null);
        boolean direct = j.optBoolean("direct", false) && has(Manifest.permission.CALL_PHONE);
        return start(new Intent(direct ? Intent.ACTION_CALL : Intent.ACTION_DIAL, u), js("ok", true));
    }

    // ---- permissions ----

    private String perms() {
        return js("mic", has(Manifest.permission.RECORD_AUDIO),
                "contacts", has(Manifest.permission.READ_CONTACTS),
                "call", has(Manifest.permission.CALL_PHONE));
    }

    private String askPerms() {
        List<String> need = new ArrayList<>();
        String[] all = {Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE};
        for (String p : all) if (!has(p)) need.add(p);
        if (!need.isEmpty()) a.requestPermissions(need.toArray(new String[0]), 5);
        return perms();
    }

    private String appSettings() {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", a.getPackageName(), null));
        return start(i, js("ok", true));
    }
}
